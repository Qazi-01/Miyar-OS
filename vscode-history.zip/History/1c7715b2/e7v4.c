#include "string.h"

void *memcpy(void *dest, const void *src, size_t count)
{
    unsigned char *d = (unsigned char *)dest;
    const unsigned char *s = (const unsigned char *)src;

    while (count--)
    {
        *d++ = *s++;
    }

    return dest;
}

void *memset(void *dest, int value, size_t count)
{
    
}