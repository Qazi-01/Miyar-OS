#include "exceptions.h"
#include "panic.h"

void exception_handler(struct registers *regs)
{
    (void)regs;

    panic("Divide by Zero Exception");
}