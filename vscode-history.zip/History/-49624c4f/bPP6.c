#include "exceptions.h"
#include "panic.h"

void exception_handler(void)
{
    (void)regs;

    panic("Divide by Zero Exception");
}