#ifndef KEYBOARD_H
#define KEYBOARD_H

#include <stdint.h>

char keyboard_getchar(void);
void keybard_init(void);

uint8_t inb(uint16_t port)
#endif