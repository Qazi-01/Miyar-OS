global isr0
extern isr0_handler

section .text

isr0:
    cli
    push byte 0
    push byte 0
    jmp isr_common_stub

isr_common_stub:
    pusha
    call isr0_handler
    add esp, 4

    popa

    iretd

