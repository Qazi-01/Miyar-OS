global isr_stub_0
extern 