#ifndef FAT32_H
#define FAT32_H

#include <stdint.h>
#include <stdbool.h>
#include "drivers/disk.h"

bool fat32_detect(const disk_t *disk);

#endif