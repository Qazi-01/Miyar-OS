#ifndef FS_H
#define FS_H

#include <stdbool.h>
#include "drivers/disk.h"

#endif