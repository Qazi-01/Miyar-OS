#ifndef FS_H
#define FS_H

#include <stdbool.h>
#include "drivers/disk.h"

typedef struct {
    const disk_t *disk;
    bool mounted;
} filesystem_t;

void fs_init(void);
const filesystem_t* fs_get(void);
bool fs_mount(const disk_t *disk);

#endif