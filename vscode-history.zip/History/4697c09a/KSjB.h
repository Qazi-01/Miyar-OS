#ifndef DISK_H
#define DISK_H

#include <stdint.h>
#include "ata.h"

typedef struct {
    uint8_t drive;
}

#endif