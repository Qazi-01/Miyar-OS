#ifndef DISK_H
#define DISK_H

#include <stdint.h>
#include "ata.h"

typedef struct {
    const ata_device_t* device;
}

#endif