#include "fs/path.h"

bool path_parse(const char *path, path_t *result)
{
    
}