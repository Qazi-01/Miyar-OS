#include "fs/path.h"

bool path_parse()