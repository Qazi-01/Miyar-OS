#include "fs/path.h"
#include "lib/string.h"

bool path_parse(const char *path, path_t *result)
{
    if (path == 0 || result == 0)
    {
        return false;
    }

    result->count = 0;
    result->absolute = false;

    if (*path == '/')
    {
        result->absolute = true;
        path++;
    }

    while (*path)
    {
        int length = 0;

        while (*path && *path != '/')
        {
            if (length >= PATH_MAX_NAME - 1)
            {
                return false;
            }

            result->components[result->count][length++] = 
        }
    }
}